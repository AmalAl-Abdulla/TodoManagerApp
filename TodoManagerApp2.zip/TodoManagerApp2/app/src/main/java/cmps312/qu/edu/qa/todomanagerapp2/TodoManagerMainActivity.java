package cmps312.qu.edu.qa.todomanagerapp2;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


public class TodoManagerMainActivity extends AppCompatActivity {
    ListView listViewItems;
    Button buttonAddItems;
    ArrayList<TodoItems> getListItems;
    TextView textViewTitle ;
    TextView textViewPriority ;
    CheckBox checkBoxStatus;
    TextView textViewTime;
    TextView textViewDate ;
    TodoManagerAdapter todoManagerAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_manager_main);
        listViewItems = (ListView) findViewById(R.id.items_list);
        getListItems = new ArrayList<>();
        getListItems.add(new TodoItems("Play sport",false,2
                ,"17/2/2017","12:45"));
        getListItems.add(new TodoItems("Read book",true,1
                ,"3/3/2015","5:00"));
        todoManagerAdapter =new TodoManagerAdapter(this, getListItems);
        listViewItems.setAdapter(todoManagerAdapter);
        buttonAddItems = (Button) findViewById(R.id.add_items_button);
        buttonAddItems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(TodoManagerMainActivity.this, TodoItemsActivity.class);
                startActivity(i);
            }
        });
    }

    class TodoManagerAdapter extends ArrayAdapter<TodoItems> {
        public TodoManagerAdapter(Context c, ArrayList<TodoItems> todoItemsList) {
            super(c, R.layout.items_list_row, todoItemsList);
        }

        public View getView(int position, View view, ViewGroup parent) {

            if (view == null) {
                LayoutInflater inflater =  LayoutInflater.from(getContext());
                view = inflater.inflate(R.layout.items_list_row, parent, false);
                 textViewTitle = view.findViewById(R.id.row_title_text_view);
                 textViewPriority = view.findViewById(R.id.row_priority_text_view);
                 checkBoxStatus = view.findViewById(R.id.row_status_check_box);
                 textViewTime = view.findViewById(R.id.row_time_text_view);
                 textViewDate = view.findViewById(R.id.row_date_text_view);

            }
            textViewTitle.setText(getItem(position).getTitle());
            if (getItem(position).isStatus())
                checkBoxStatus.setChecked(true);
            else
                checkBoxStatus.setChecked(false);
            if (getItem(position).getPriority() == 0)
                textViewPriority.setText("LOW");
            else if (getItem(position).getPriority() == 1)
                textViewPriority.setText("MEDIUM");
            else if (getItem(position).getPriority() == 2)
                textViewPriority.setText("HIGH");
            textViewTime.setText(getItem(position).getTime()+"");
            textViewDate.setText(getItem(position).getDate()+"");

            return  view;
        }

    }
/*
    private ArrayList<TodoItems> getLists(){
        ArrayList<TodoItems> items = new ArrayList<>();


            String title = getIntent().getStringExtra(TodoItemsActivity.TITLE);
            titles.add(title);
            Date date = (Date) getIntent().getSerializableExtra(TodoItemsActivity.DATE);
            dates.add(date);
            Date time = (Date) getIntent().getSerializableExtra(TodoItemsActivity.TIME);
            times.add(time);
            Boolean status = getIntent().getBooleanExtra(TodoItemsActivity.STATUS, false);
            statuses.add(status);
            int priority = getIntent().getIntExtra(TodoItemsActivity.PRIORITY, 0);
            priorities.add(priority);

            SharedPreferences p=getSharedPreferences("MyData",MODE_PRIVATE);
            String title= p.getString("title","");
            titles.add(title);
            int priority = p.getInt("priority",0);
            priorities.add(priority);
            Boolean status =p.getBoolean("status",false);
            statuses.add(status);
            String time = p.getString("time","");
            times.add(time);
            String date = p.getString("date","");
            dates.add(date);
        for(int i=0;i<TodoItemsActivity.itemsNumber;i++) {
            items.add(new TodoItems(titles.get(i), statuses.get(i), priorities.get(i), dates.get(i)
                    , times.get(i)));
        }
            return items;

    }
*/
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) { //request code is for activities
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode == Activity.RESULT_OK){
            String title = data.getStringExtra(TodoItemsActivity.TITLE);
            String date =  data.getStringExtra(TodoItemsActivity.DATE);
            String time =  data.getStringExtra(TodoItemsActivity.TIME);
            Boolean status = data.getBooleanExtra(TodoItemsActivity.STATUS, false);
            int priority = data.getIntExtra(TodoItemsActivity.PRIORITY, 0);

            getListItems.add(new TodoItems(title, status, priority, date, time));

        }
    }
}


