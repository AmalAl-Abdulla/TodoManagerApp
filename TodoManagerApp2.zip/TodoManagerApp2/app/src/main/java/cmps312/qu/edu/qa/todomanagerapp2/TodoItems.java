package cmps312.qu.edu.qa.todomanagerapp2;

import java.util.Date;

public class TodoItems {

    private String title;
    private boolean status;
    private int priority;
    private String date;
    private String time;

    //private String sTime,sDate;

    public TodoItems() { //initial values of attributes
        this.title = "";
        this.status = false;
        this.priority = 0;
        this.date = "";
        this.time = "";
    }
/*
    public TodoItems(String title, boolean status, int priority, String date, String time) {
        this.title = title;
        this.status = status;
        this.priority = priority;
        sDate = date;
        sTime = time;
    }*/


    public TodoItems(String title, boolean status, int priority, String date, String time) {
        this.title = title;
        this.status = status;
        this.priority = priority;
        this.date = date;
        this.time = time;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
