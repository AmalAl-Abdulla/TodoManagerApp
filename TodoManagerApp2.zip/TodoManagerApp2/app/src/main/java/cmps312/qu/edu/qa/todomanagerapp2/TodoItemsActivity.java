package cmps312.qu.edu.qa.todomanagerapp2;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class TodoItemsActivity extends AppCompatActivity {
    private TodoItems todoItems;
    private EditText editTextTitle;
    private RadioGroup radioGroupStatus, radioGroupPriority;
    private Button buttonDate, buttonTime, buttonSubmit,buttonCancel,buttonReset;
    private TextView textViewDate, textViewTime;
    private Calendar calendar = Calendar.getInstance();
    private DateFormat dateFormat = DateFormat.getDateInstance();
    private DateFormat timeFormat = DateFormat.getTimeInstance();
    private DatePickerDialog.OnDateSetListener dateSetListener;
    private TimePickerDialog.OnTimeSetListener timeSetListener;
    static final String TITLE = "TITLE";
    static final String PRIORITY = "PRIORITY";
    static final String STATUS = "STATUS";
    static final String TIME = "TIME";
    static final String DATE = "DATE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todo_items);
        todoItems = new TodoItems();
        editTextTitle = (EditText) findViewById(R.id.edit_text_title);
        editTextTitle.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //left blank
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                todoItems.setTitle(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {
                //left blank
            }
        });
        radioGroupStatus = (RadioGroup) findViewById(R.id.status_radio_group);
        radioGroupStatus.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i){
                    case R.id.done_radio_group: todoItems.setStatus(true);
                        break;
                    case R.id.not_done_radio_group: todoItems.setStatus(false);
                }
            }
        });
        radioGroupPriority = (RadioGroup) findViewById(R.id.priority_radio_group);
        radioGroupPriority.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i){
                    case R.id.low_radio_group: todoItems.setPriority(0);
                        break;
                    case R.id.med_radio_group: todoItems.setPriority(1);
                        break;
                    case R.id.high_radio_group: todoItems.setPriority(2);
                }
            }
        });
        textViewDate = (TextView) findViewById(R.id.date_format_label);
        buttonDate = (Button) findViewById(R.id.date_button);
        buttonDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createDateDialog();
            }
        });
        dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {

                calendar.set(Calendar.YEAR,year);
                calendar.set(Calendar.MONTH,month);
                calendar.set(Calendar.DAY_OF_MONTH,day);
                todoItems.setDate(dateFormat.format(calendar.getTime()));
                textViewDate.setText(dateFormat.format(calendar.getTime()));
            }
        };

        buttonTime = (Button) findViewById(R.id.time_button);
        textViewTime = (TextView) findViewById(R.id.time_format_label);
        buttonTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createTimeDialog();
            }
        });
        timeSetListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int hour, int minute) {
                calendar.set(Calendar.HOUR,hour);
                calendar.set(Calendar.MINUTE,minute);
                todoItems.setTime(timeFormat.format(calendar.getTime()));
                textViewTime.setText(timeFormat.format(calendar.getTime()));
            }
        };

        buttonSubmit = (Button) findViewById(R.id.submit_button);
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //here
                Intent intent = new Intent();
                intent.putExtra(TITLE,todoItems.getTitle());
                intent.putExtra(STATUS,todoItems.isStatus());
                intent.putExtra(PRIORITY,todoItems.getPriority());
                intent.putExtra(DATE,todoItems.getDate());
                intent.putExtra(TIME,todoItems.getTime());
                setResult(Activity.RESULT_OK,intent);

                /**
               SharedPreferences p=getSharedPreferences("MyData",MODE_PRIVATE);
                SharedPreferences.Editor e=p.edit();
                e.putString("title",todoItems.getTitle());
                e.putInt("priority",todoItems.getPriority());
                e.putBoolean("status",todoItems.isStatusCompleted());
                e.putString("time",todoItems.getTime()+"");
                e.putString("date",todoItems.getDate()+"");
                e.commit();
                 */
                finish();
            }
        });
        buttonCancel = (Button) findViewById(R.id.cancel_button);
        buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        buttonReset = (Button) findViewById(R.id.reset_button);
        buttonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextTitle.setText("");
                textViewTime.setText(R.string.time_initial);
                textViewDate.setText(R.string.date_initial);
                radioGroupPriority.clearCheck();
                radioGroupStatus.clearCheck();
            }
        });
    }

    public void createDateDialog(){

        new DatePickerDialog(this,dateSetListener,calendar.get(Calendar.YEAR)
                ,calendar.get(Calendar.MONTH)
                ,calendar.get(Calendar.DAY_OF_MONTH))
                .show();
    }

    public void createTimeDialog(){

        new TimePickerDialog(this,timeSetListener,calendar.get(Calendar.HOUR)
                ,calendar.get(Calendar.MINUTE)
                ,true)
                .show();
    }

}
